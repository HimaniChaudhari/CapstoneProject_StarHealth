package com.starhealth.eshop.enums;

public enum ResponseStatus
{
    success,
    error
}
