package com.starhealth.eshop.enums;

public enum Role {
    user,
    manager,
    admin
}
