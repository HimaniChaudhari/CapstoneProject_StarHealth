package com.starhealth.eshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
