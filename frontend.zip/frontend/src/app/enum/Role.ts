export enum Role {
    Customer = 'ROLE_CUSTOMER',
    Employee = 'ROLE_EMPLOYEE',
    Manager = 'ROLE_MANAGER'
}
