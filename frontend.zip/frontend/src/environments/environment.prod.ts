export const environment = {
  production: true
};
export const apiUrl = '/';
